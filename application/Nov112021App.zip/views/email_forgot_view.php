<body style="font-family: 'Source Sans Pro', sans-serif; padding:0; margin:0;">
    <table style="max-width: 750px; margin: 0px auto; width: 100% ! important; background: #F3F3F3; padding:30px 30px 30px 30px;" width="100% !important"border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td style="text-align: center; background: #fff;">
                <table width="100%" border="0" cellpadding="30" cellspacing="0">
                    <tr>
                        <td>
                            <!-- <img style="max-width: 125px; width: 100%;padding: 10px;"  src="<?php echo base_url(); ?>backend_assets/img/logo.png" > -->
                            <h2>Directry</h>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td style="text-align: center;">
                <table width="100%" border="0" cellpadding="30" cellspacing="0" bgcolor="#fff">
                    <tr>
                        <td>
                            <h3 style="color: #333; font-size: 28px; font-weight: normal; margin: 0; text-transform: capitalize;">Forgot Password</h3>
                            <p style="text-align: left; color: #333; font-size: 16px; line-height: 28px;">Hello </p>
                            <p style="text-align: left;color: #333; font-size: 16px; line-height: 28px;">You recently requested to reset your password for your cgrobinson`s account. Please click on button To reset your password: </p>
                            <table class="body-action" align="center" width="100%" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td align="center">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td align="center">
                                                    <table border="0" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td>
                                                                <a style="border: 10px #dd4b39 solid;background:#dd4b39;color: white;text-decoration: none;" class="button button--green" href="<?php echo $url; ?>">Forgot Password</a>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table> 
                           <!--  <p style="text-align: left;color: #333; font-size: 16px; line-height: 28px;">If you didn't generate this link, don't worry. You can login with your old password. This link is only for one time use.</p>  
                            <p style="text-align: left;color: #333; font-size: 16px; line-height: 28px;">Thanks,<br><?php ?> team</p> -->  
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td style="text-align: center;">
                <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#fff">
                    <tr>
                        <td style="padding: 10px;background: #23c466;color: #fff;">Copyright &copy; <?php echo date('Y'); ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
<!-- </html> --