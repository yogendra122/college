<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'university';
$config['googleplus']['client_id']        = '695169269940-3f7im8kifgi36i4tjb0sech2asfuj82u.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'ZrAH3orleDLX12C6lhW_rBDT';
$config['googleplus']['redirect_uri']     = 'http://localhost/universitybooking-loai/oauth2callback';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

